# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Creating Bronze Tables

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating categories table

# COMMAND ----------

env="dev"
print(env)

# COMMAND ----------

def createTable_categories(environment):
    print(f'Creating categories table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`categories`
                    (
                            category_id int,
                            category_department_id int,
                            category_name string
                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating orders table

# COMMAND ----------

def createTable_orders(environment):
    print(f'Creating raw_Traffic table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`orders`
                        (
                            order_id INT,
                            order_date timestamp,
                            order_customer_id int,
                            order_status string

                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating order_items table

# COMMAND ----------

def createTable_order_items(environment):
    print(f'Creating order_items table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`order_items`
                        (
                            order_item_id INT,
                            order_item_order_id int,
                            order_item_product_id int,
                            order_item_quantity int,
                            order_item_subtotal float,
                            order_item_product_price float
                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating customers table

# COMMAND ----------

def createTable_customers(environment):
    print(f'Creating customers table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`customers`
                        (
                            customer_id INT,
                            customer_fname string,
                            customer_lname string,
                            customer_email string,
                            customer_password string,
                            customer_street string,
                            customer_city string,
                            customer_state string,
                            customer_zipcode string
                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating products table

# COMMAND ----------

def createTable_products(environment):
    print(f'Creating products table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`products`
                        (
                            product_id INT,
                            product_category_id int,
                            product_name string,
                            product_description string,
                            product_price float,
                            product_image string
                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #### Creating departments table

# COMMAND ----------

def createTable_departments(environment):
    print(f'Creating departments table in {environment}_catalog')
    spark.sql(f"""CREATE TABLE IF NOT EXISTS `{environment}_catalog`.`bronze`.`departments`
                        (
                            department_id INT,
                            department_name string
                    );""")
    
    print("************************************")

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC
# MAGIC ## Calling all functions

# COMMAND ----------

createTable_products(env)
createTable_orders(env)
createTable_departments(env)
createTable_order_items(env)
createTable_customers(env)
createTable_categories(env)


#create_Silver_Schema(env,silver_path)
#create_Gold_Schema(env,gold_path)

# COMMAND ----------

# MAGIC %md
# MAGIC