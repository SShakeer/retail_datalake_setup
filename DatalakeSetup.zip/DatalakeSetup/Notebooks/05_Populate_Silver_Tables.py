# Databricks notebook source
# MAGIC %md
# MAGIC #### 01_Populate orders table

# COMMAND ----------

environment="dev"
print(environment)

# COMMAND ----------

from pyspark.sql.functions import *

df_orders = spark.read.table(f"`{environment}_catalog`.`bronze`.orders")
df_orders_dedup = df_orders.dropDuplicates()

print('Replacing NULL values on String Columns with "Unknown" ', end='')
string_columns = df_orders_dedup.columns
df_string = df_orders_dedup.fillna('Unknown', subset=string_columns)

print('Replacing NULL values on Numeric Columns with "0" ', end='')
df_orders_clean = df_string.fillna(0, subset=string_columns)

print('Creating Transformed Time column: ', end='')
df_timestamp = df_orders_clean.withColumn('Transformed_Time', current_timestamp())

# Create final dataframe as silver table
df_timestamp.write.mode('overwrite').saveAsTable(f"`{environment}_catalog`.`silver`.orders")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 02_Populate order_items table

# COMMAND ----------

from pyspark.sql.functions import *
df_order_items=spark.read.table(f"`{environment}_catalog`.`bronze`.order_items")
df_orders_dedup1=df_order_items.dropDuplicates()
print('Replacing NULL values on String Columns with "Unknown" ' , end='')

columns = df_orders_dedup1.columns
df_string1 = df_orders_dedup1.fillna('Unknown',subset= columns)
print('Replacing NULL values on Numeric Columns with "0" ' , end='')
df_orders_clean1 = df_string1.fillna(0,subset = columns)

print('Creating Transformed Time column : ',end='')
df_timestamp1 = df_orders_clean1.withColumn('Transformed_Time',current_timestamp())

##create final dataframe as silver table
df_timestamp1.write.mode('overwrite').saveAsTable(f"`{environment}_catalog`.`silver`.order_items")


# COMMAND ----------

# MAGIC %md
# MAGIC #### 03_Populate products table

# COMMAND ----------

from pyspark.sql.functions import *
df_prod=spark.read.table(f"`{environment}_catalog`.`bronze`.products")

##create final dataframe as silver table
df_prod.write.mode('overwrite').saveAsTable(f"`{environment}_catalog`.`silver`.products")


# COMMAND ----------

# MAGIC %md
# MAGIC #### 04_Populate catagories table

# COMMAND ----------

from pyspark.sql.functions import *
df_cata=spark.read.table(f"`{environment}_catalog`.`bronze`.categories")

##create final dataframe as silver table
df_cata.write.mode('overwrite').saveAsTable(f"`{environment}_catalog`.`silver`.catagories")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 05_Populate customers table

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dev_catalog.silver.customers
# MAGIC as
# MAGIC select * from dev_catalog.bronze.customers;

# COMMAND ----------

# MAGIC %md
# MAGIC #### 06_Populate dept table

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dev_catalog.silver.departments
# MAGIC as
# MAGIC select * from dev_catalog.bronze.departments;

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC