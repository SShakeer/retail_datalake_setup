# Databricks notebook source
# MAGIC %md
# MAGIC ### KPI (Key Performance Indicators)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get top 3 products sold in the month of 2014 January by revenue.
# MAGIC
# MAGIC * Consider only those orders which are either in COMPLETE or CLOSED status.
# MAGIC * Highest revenue generating product should come at top.
# MAGIC * Output should contain product_id, product_name, revenue, product_rank. 
# MAGIC
# MAGIC * revenue and product_rank are derived fields.
# MAGIC
# MAGIC * Data should be sorted in descending order by revenue.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM ( SELECT q.*,
# MAGIC     dense_rank() OVER (
# MAGIC     ORDER BY q.revenue desc) AS product_rank
# MAGIC     FROM (
# MAGIC         SELECT p.product_id, p.product_name,
# MAGIC              round(sum(oi.order_item_subtotal)::numeric ,2) AS revenue
# MAGIC     FROM orders o JOIN order_items oi
# MAGIC             ON o.order_id = oi.order_item_order_id
# MAGIC         JOIN products p
# MAGIC             ON oi.order_item_product_id = p.product_id
# MAGIC     WHERE o.order_status IN ('COMPLETE','CLOSED') AND to_char(order_date,'yyyy-MM-dd') LIKE '2014-01%'
# MAGIC     GROUP BY p.product_id, p.product_name
# MAGIC     ORDER BY revenue desc
# MAGIC     LIMIT 3
# MAGIC       ) q
# MAGIC     ) nq

# COMMAND ----------

# MAGIC %md
# MAGIC #### KPI:2
# MAGIC
# MAGIC * Get top 3 products sold in the month of 2014 January under selected categories by revenue. The categories are Cardio Equipment and Strength Training.

# COMMAND ----------

# MAGIC %sql 
# MAGIC /*     
# MAGIC SELECT * FROM ( SELECT nq.*,
# MAGIC     dense_rank() OVER (
# MAGIC         PARTITION BY nq.category_id
# MAGIC         ORDER BY nq.category_id, nq.revenue DESC
# MAGIC     ) AS product_rank
# MAGIC FROM ( SELECT  cat.category_id,cat.category_name, P.product_id,p.product_name,
# MAGIC     round(sum(oi.order_item_subtotal::numeric),2) AS revenue
# MAGIC     FROM orders o 
# MAGIC     JOIN order_items oi
# MAGIC         ON o.order_id = oi.order_item_order_id
# MAGIC     JOIN products p
# MAGIC         ON  p.product_id = oi.order_item_product_id
# MAGIC     JOIN categories cat 
# MAGIC         ON cat.category_id = p.product_category_id
# MAGIC     WHERE o.order_status IN ('COMPLETE' , 'CLOSED')
# MAGIC     AND to_char(order_date, 'yyyy-MM-dd') LIKE '2014-01%'
# MAGIC     AND cat.category_name IN ('Cardio Equipment','Strength Training')
# MAGIC     GROUP BY cat.category_id,cat.category_department_id,cat.category_name,p.product_id
# MAGIC     ORDER BY cat.category_id
# MAGIC      ) nq
# MAGIC             )nq1
# MAGIC
# MAGIC             */

# COMMAND ----------

orders = spark.read.table("dev_catalog.silver.orders")

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as _sum, round as _round, dense_rank, to_date
from pyspark.sql.window import Window


# Example schema and data
# Create DataFrames for orders, order_items, products, and categories
# Adjust these as needed to match your actual schema
orders = spark.read.table("dev_catalog.silver.orders")
order_items = spark.read.table("dev_catalog.silver.order_items")
products = spark.read.table("dev_catalog.silver.products")
categories = spark.read.table("dev_catalog.silver.catagories")


# Filter orders by status and date
filtered_orders = orders.filter(
    (col("order_status").isin("COMPLETE", "CLOSED")) &
    (col("order_date").startswith("2014-01"))
)


# COMMAND ----------

# Join tables
joined_data = filtered_orders\
    .join(order_items, orders.order_id == order_items.order_item_order_id, "inner")\
    .join(products, order_items.order_item_product_id == products.product_id, "inner")\
    .join(categories, products.product_category_id == categories.category_id, "inner")

# COMMAND ----------

# Filter by category_name
filtered_data = joined_data.filter(
    col("category_name").isin("Cardio Equipment", "Strength Training")
)

# COMMAND ----------

# Aggregate revenue by category and product
aggregated_data = filtered_data\
    .groupBy("category_id", "category_name", "product_id", "product_name")\
    .agg(_round(_sum("order_item_subtotal"), 2).alias("revenue"))

# COMMAND ----------

# Define window for dense_rank
window_spec = Window.partitionBy("category_id").orderBy(col("revenue").desc())

# Apply dense_rank
ranked_data = aggregated_data.withColumn("product_rank", dense_rank().over(window_spec))

# Show the result
ranked_data.show(3)

# COMMAND ----------

ranked_data.write.mode("overwrite").format("delta").saveAsTable("dev_catalog.gold.cata_revenue")

# COMMAND ----------

# MAGIC %md
# MAGIC #### KPI3: Customer order count
# MAGIC
# MAGIC * Get order count per customer for the month of 2014 January.
# MAGIC
# MAGIC * Tables - orders and customers
# MAGIC * Data should be sorted in descending order by count and ascending order by customer id.
# MAGIC * Output should contain customer_id, customer_first_name, customer_last_name and customer_order_count.

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count

orders = spark.read.table("dev_catalog.silver.orders") 

customers = spark.read.table("dev_catalog.silver.customers")

# Filter orders for January 2014
filtered_orders = orders.filter(col("order_date").startswith("2014-01"))

# Count orders per customer
customer_order_count = filtered_orders \
    .groupBy("customer_id") \
    .agg(count("order_id").alias("customer_order_count"))

# Join with customers table to get customer details
result = customer_order_count \
    .join(customers, "customer_id", "inner") \
    .select("customer_id", "customer_first_name", "customer_last_name", "customer_order_count") \
    .orderBy(col("customer_order_count").desc(), col("customer_id"))

# Show the result
result.show()


# COMMAND ----------

# MAGIC %md
# MAGIC #### KPI: Revenue Per Customer
# MAGIC * Get the revenue generated by each customer for the month of 2014 January
# MAGIC * Output should contain customer_id, customer_first_name, customer_last_name, customer_revenue.
# MAGIC * Consider only COMPLETE and CLOSED orders
# MAGIC * If there are no orders placed by customer, then the corresponding revenue for a give customer should be 0.

# COMMAND ----------

orders = spark.read.table("dev_catalog.silver.orders") 
customers = spark.read.table("dev_catalog.silver.customers")
order_items = spark.read.table("dev_catalog.silver.order_items")

# Filter orders for January 2014 and status COMPLETE or CLOSED
filtered_orders = orders.filter(
    (col("order_status").isin("COMPLETE", "CLOSED")) &
    (col("order_date").startswith("2014-01"))
)

# COMMAND ----------

order_revenue = filtered_orders\
    .join(order_items, filtered_orders.order_id == order_items.order_item_order_id, "left")\
    .groupBy("customer_id")\
    .agg(_sum("order_item_subtotal").alias("customer_revenue"))


# COMMAND ----------

customer_revenue = customers\
    .join(order_revenue, "customer_id", "left")\
    .select(
        "customer_id",
        "customer_first_name",
        "customer_last_name",
        when(col("customer_revenue").isNull(), 0).otherwise(col("customer_revenue")).alias("customer_revenue")
    )\
    .orderBy(col("customer_revenue").desc(), col("customer_id"))

# COMMAND ----------

customer_revenue.show()