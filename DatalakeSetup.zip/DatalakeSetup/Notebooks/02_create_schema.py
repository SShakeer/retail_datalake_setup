# Databricks notebook source
# MAGIC %sql
# MAGIC show external locations

# COMMAND ----------

#landing = spark.sql("describe external location `landing`").select("url").collect()[0][0]
bronze_path = spark.sql("describe external location `bronze`").select("url").collect()[0][0]
print(bronze_path)
silver_path = spark.sql("describe external location `silver`").select("url").collect()[0][0]
print(silver_path)
gold_path = spark.sql("describe external location `gold`").select("url").collect()[0][0]
print(gold_path)

# COMMAND ----------

env="dev"
print(env)

# COMMAND ----------

def create_Bronze_Schema(environment,path):
    print(f'Using {environment}_catalog ')
    spark.sql(f""" USE CATALOG '{environment}_catalog'""")
    print(f'Creating Bronze Schema in {environment}_catalog')
    spark.sql(f"""CREATE SCHEMA IF NOT EXISTS `bronze` MANAGED LOCATION '{path}/bronze'""")
    print("************************************")

# COMMAND ----------

def create_Silver_Schema(environment,path):
    print(f'Using {environment}_catalog ')
    spark.sql(f""" USE CATALOG '{environment}_catalog'""")
    print(f'Creating Silver Schema in {environment}_catalog')
    spark.sql(f"""CREATE SCHEMA IF NOT EXISTS `silver` MANAGED LOCATION '{path}/silver'""")
    print("************************************")

# COMMAND ----------

def create_Gold_Schema(environment,path):
    print(f'Using {environment}_Catalog ')
    spark.sql(f""" USE CATALOG '{environment}_catalog'""")
    print(f'Creating Gold Schema in {environment}_catalog')
    spark.sql(f"""CREATE SCHEMA IF NOT EXISTS `gold` MANAGED LOCATION '{path}/gold'""")
    print("************************************")

# COMMAND ----------

create_Bronze_Schema(env,bronze_path)

# COMMAND ----------

create_Silver_Schema(env,silver_path)

# COMMAND ----------

create_Gold_Schema(env,gold_path)