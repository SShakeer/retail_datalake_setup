# Databricks notebook source
print("welcome to UC")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS dev_catalog
# MAGIC --MANAGED LOCATION 'abfss://unitycatalog@eminentadlsgen2.dfs.core.windows.net/bronze'

# COMMAND ----------

# MAGIC %sql
# MAGIC USE CATALOG dev_catalog;

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema IF NOT EXISTS silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table silver.test
# MAGIC (
# MAGIC   empno int,
# MAGIC   ename string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into table  silver.test values (100,'ABC')

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog dev_catalog;
# MAGIC drop schema silver cascade;
# MAGIC