# Databricks notebook source
# MAGIC %md
# MAGIC #### 01_Load catagories table

# COMMAND ----------

landing="abfss://unitycatalog@eminentadlsgen2.dfs.core.windows.net/data"
environment="dev"
print(landing)
print(environment)

# COMMAND ----------

dbutils.fs.ls("abfss://unitycatalog@eminentadlsgen2.dfs.core.windows.net/data")

# COMMAND ----------

#df_catagories=spark.read.format("csv").option("header", "true").load(landing+'/categories.txt')

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

print("Reading the catagories Data :  ", end='')

schema = StructType([
        StructField('category_id',IntegerType()),
        StructField('category_department_id',IntegerType()),
        StructField('category_name',StringType())])
    
df_catagories=spark.read.format("csv").option("header", "true").schema(schema).load(landing+'/categories.txt')
print("Reading the catagories Data :  ", end='')
print('Reading Succcess !!')
print('*******************')



# COMMAND ----------

df_catagories.display()

# COMMAND ----------

print(f'Writing data to {environment}_catalog catagories table', end='' )

df_catagories.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`categories`") 

print('Write Success')
print("****************************")

# COMMAND ----------

# MAGIC %sql
# MAGIC --truncate table dev_catalog.bronze.categories;
# MAGIC
# MAGIC select * from dev_catalog.bronze.categories;
# MAGIC --select * from dev_catalog.bronze.products;
# MAGIC --select * from dev_catalog.bronze.customers;
# MAGIC --select * from dev_catalog.bronze.departments limit 10;

# COMMAND ----------

# MAGIC %md
# MAGIC #### 02_Load products table

# COMMAND ----------

print("Reading the products Data :  ", end='')

schema1 = StructType([
        StructField('product_id',IntegerType()),
        StructField('product_category_id',IntegerType()),
        StructField('product_name',StringType()),
        StructField('product_description',StringType()),
        StructField('product_price',DoubleType()),
        StructField('product_image',StringType())
        ])
    
df_products=spark.read.format("csv").option("header", "true").schema(schema1).load(landing+'/products.txt')
print("Reading the products Data :  ", end='')
print('Reading Succcess !!')
print('*******************')

# COMMAND ----------

print(f'Writing data to {environment}_catalog products table', end='' )

df_products.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`products`") 

print('Write Success')
print("******* *********************")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 03_Load orders table

# COMMAND ----------

print("Reading the orders Data :  ", end='')

ordersschema = StructType([
        StructField('order_id',IntegerType()),
        StructField('order_date',TimestampType()),
        StructField('order_customer_id',IntegerType()),
        StructField('order_status',StringType())
        ])
    
df_orders=spark.read.format("csv").option("header", "true").schema(ordersschema).load(landing+'/orders.txt')
print("Reading the orders Data :  ", end='')
print('Reading Succcess !!')
print('*******************')

# COMMAND ----------

print(f'Writing data to {environment}_catalog orders table', end='' )

df_orders.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`orders`") 

print('Write Success')
print("******* *********************")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 04_Load order_items table

# COMMAND ----------

print("Reading the orders Data :  ", end='')

orderitemsschema = StructType([
        StructField('order_item_id',IntegerType()),
        StructField('order_item_order_id',IntegerType()),
        StructField('order_item_product_id',IntegerType()),
        StructField('order_item_quantity',StringType()),
        StructField('order_item_subtotal',DoubleType()),
        StructField('order_item_product_price',DoubleType())
        ])
    
df_order_items=spark.read.format("csv").option("header", "true").schema(orderitemsschema).load(landing+'/order_items.txt')
print("Reading the order items Data :  ", end='')
print('Reading Succcess !!')
print('*******************')

# COMMAND ----------

print(f'Writing data to {environment}_catalog order items table', end='' )

df_order_items.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`order_items`") 

print('Write Success')
print("******* *********************")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 05_Load customers table

# COMMAND ----------

print("Reading the custoemrs Data :  ", end='')

cust_schema = StructType([
        StructField('customer_id',IntegerType()),
        StructField('customer_fname',StringType()),
        StructField('customer_lname',StringType()),
        StructField('customer_email',StringType()),
        StructField('customer_password',StringType()),
        StructField('customer_street',StringType()),
        StructField('customer_city',StringType()),
        StructField('customer_state',StringType()),
        StructField('customer_zipcode',StringType())
        ])
    
df_cust=spark.read.format("csv").option("header", "true").schema(cust_schema).load(landing+'/customers.txt')
print("Reading the customers Data :  ", end='')
print('Reading Succcess !!')
print('*******************')

# COMMAND ----------

print(f'Writing data to {environment}_catalog customrt table', end='' )

df_cust.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`customers`") 

print('Write Success')
print("******* *********************")

# COMMAND ----------

# MAGIC %md
# MAGIC #### 06_Load department table

# COMMAND ----------

print("Reading the department Data :  ", end='')

dept_schema = StructType([
        StructField('department_id ',IntegerType()),
        StructField('department_name',StringType())
        ])
    
df_dept=spark.read.format("csv").option("header", "true").schema(dept_schema).load(landing+'/departments.txt')
print("Reading the departments Data :  ", end='')
print('Reading Succcess !!')
print('*******************')

# COMMAND ----------

print(f'Writing data to {environment}_catalog dept table', end='' )

df_dept.write.mode("append").format("delta").insertInto(f"`{environment}_catalog`.`bronze`.`departments`") 

print('Write Success')
print("******* *********************")

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC